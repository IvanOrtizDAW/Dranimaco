<?php
/**
 * Notify in customizer system
 *
 * @package zerif-lite
 */

if ( ! class_exists( 'Ti_Customizer_Notify_System' ) ) {
	/**
	 * Class Ti_Customizer_Notify_System
	 */
	class Ti_Customizer_Notify_System {
		/* TODO - recommended actions, demo import */
	}
}
