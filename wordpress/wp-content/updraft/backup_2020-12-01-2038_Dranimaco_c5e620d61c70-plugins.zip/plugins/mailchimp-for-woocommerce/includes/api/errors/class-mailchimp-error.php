<?php

/**
 * Class MailChimp_WooCommerce_Error
 */
class MailChimp_WooCommerce_Error extends \Exception
{

}
